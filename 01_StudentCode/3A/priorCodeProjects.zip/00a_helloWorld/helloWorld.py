# Hello World!, Ryan Kelley, v0.0

print("Hello World!")

# data types
# Integers - +/- whole numbers including 0
# Floats - +/- decimal numbers. 
# Strings - enclosed in " "

# variables 
# Variable names CANNOT START WITH NUMBERS
# Name should describe the data being stored.
# Cannot use Python keywords as variables. 
# snake_case -- all words are lower case, separated by _ 
# camelCase -- first word lower, all other words upper, no spaces. 
player_health = 100
playerHealth = 100 


# gasRemaining = 10 
# currentTemp = 99.9 
# favoriteFlavor = "Vanilla"

# stringVar = "5"
# integerVar = 5

# print(stringVar + stringVar)
# print(integerVar + integerVar)

# Variable Examples 
myInteger = -1
myFloat = 0.123
myString = "I like shrimp a la mode."
myBool = False

# Printing Variables 
print(myInteger)
print(myFloat)
print(myString)
print(myBool)

